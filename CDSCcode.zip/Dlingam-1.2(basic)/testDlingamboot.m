% function [kkk,kest,Estimate_Error]=testDlingamboot(dims)
function [kkk,kest,MSE,number_connect_edge,TP,true_absence_identified,FN,FP,timeTotal,Srcc]=testDlingamboot(dims,randseed,indegree)
% function testDlingamboot()
% Version: 0.1
% Shohei Shimizu (9 Dec 2010)
% dims=7;
% randseed=1;
% indegree=2;
% % Set the randseed to the same each time
% randseed = 0;
% fprintf('Using randseed: %d\n',randseed);
% rand('seed',randseed);
% randn('seed',randseed);
%
% % parameters
% nboot = 1000
% threshold = 0.05
%
% % Generate data
% p = 3;%%%ά��
% n = 100;%%%��������
%
% B = [ [ 0 0 0 ]; [ 1 0 0 ]; [ 0 1 0 ]];%%%
% A = inv( eye( p ) - B );
%
% E = randn( p, n );
% E = sign( E ) .* E.^2;
%
% X = A * E;
% X
%%
more off;%%%%��������ҳ;more on %%%������ҳ
% randseed=1;
%----------------------------------------------------------------------%
% 1. HANDLE RANDSEED
%----------------------------------------------------------------------%

% If did not define a randseed, choose one randomly (using
% the clock to generate a truly random one).
% if ~exist('randseed'),
%     rand('seed',sum(100*clock));%%%%seed��state��twister����������������㷨������ĵڶ����������������Ʋ����������״̬����ֹ����һ���������
%     randseed = floor(rand*100000);%%%floor������ȡ����ceil������ȡ��
% end

% Tell the user which randseed was used, in case one wants
% to repeat the test with that specific randseed.
fprintf('Using randseed: %d\n',randseed);
rand('seed',randseed);
randn('seed',randseed);

%----------------------------------------------------------------------%
% 2. GENERATE A MODEL (RANDOMLY SELECT PARAMETERS)
%----------------------------------------------------------------------%

% Number of variables to use: min 2, max 20 (max set arbitrarily)
% dims = ceil(rand*19)+1;
% dims=10;
fprintf('Number of dimensions: %d\n',dims);

% Full or sparse connections?
% sparse = floor(rand*2);
% sparse=1;
% if sparse,
% %     indegree = floor(rand*5)+1;   % how many parents maximally
%     indegree=2;
%     fprintf('Sparse network, max parents = %d\n',indegree);
% else
%     indegree = Inf;               % full connections
%     fprintf('Full network.\n');
% end
parminmax = [0.5 1.5]; % [min max] standard deviation owing to parents
errminmax = [0.5 1.5]; % [min max] standard deviation owing to disturbance

% Pause briefly to allow user to inspect chosen parameters
% pause(2);%%%��ͣ2��֮��ִ����һ������

% Create the network with random weights but according to chosen parameters
fprintf('Creating network...');
[B,disturbancestd] = randnetbalanced( dims, indegree, parminmax, errminmax );
c = 2*randn(dims,1);
fprintf('Done!\n');



%----------------------------------------------------------------------%
% 3. GENERATE DATA FROM THE MODEL
%----------------------------------------------------------------------%

fprintf('Generating data...');

% Nonlinearity exponent, selected to lie in [0.5, 0.8] or [1.2, 2.0].
% (<1 gives subgaussian, >1 gives supergaussian)
q = rand(dims,1)*1.1+0.5;
ind = find(q>0.8);
q(ind) = q(ind)+0.4;

% Number of data vectors
samples =2000;

% This generates the disturbance variables, which are mutually
% independent, and non-gaussian
S = randn(dims,samples);
S = sign(S).*(abs(S).^(q*ones(1,samples)));

% This normalizes the disturbance variables to have the
% appropriate scales
S = S./((sqrt(mean((S').^2)')./disturbancestd)*ones(1,samples));

% Now we generate the data one component at a time
Xorig = zeros(dims,samples);
for i=1:dims,
    Xorig(i,:) = B(i,:)*Xorig + S(i,:) + c(i);
end

% Select a random permutation because we do not assume that we know
% the correct ordering of the variables
p = randperm(dims);
% Permute the rows of the data matrix, to give us the observed data
X = Xorig(p,:);
% Permute the rows and columns of the original generating matrix B
% so that they correspond to the actual data
Bp = B(p,p);
[aaa,kkk]=sort(p);
%%��ͼ
% Mat = abs(Bp)>0;
% graphViz4Matlab('-adjMat',Mat');
% kkk
% Permute the generating disturbance stds so that they correspond to
% the actual data
disturbancestdp = disturbancestd(p);

% Permute the generating constants so that they correspond to
% the actual data
cp = c(p);
fprintf('Done!\n');
%%
tic
[Best, stdeest, ciest, kest] = Dlingam(X);
% skeleton=Mat+Mat';
% [ Best ] = Generate_Network( skeleton,kest );
[Best, stdeest, ciest] = prune(X, kest);
timeTotal = toc; %��ʱ��/��
%%%����˳��ĺ���ָ��Spearman rank-correlation coefficient
aaa=0;
for i=1:dims
    aaa=(kest(i)-kkk(i)).^2+aaa;
end
Srcc=1-6*aaa/(dims*(dims.^2-1));

% kest
MSE=norm((Bp-Best));
%�ж��ٸ����ӱ�
connect_edge = find((Bp(:)~=0));
number_connect_edge=length(connect_edge);%%%ʵ�����ӱ߸���
% Number of true connections identified
TP=length(find((Bp(:)~=0) & (Best(:)~=0)));%%%ʶ����ȷ�ı߸���
% Number of correctly identified absence of connections
true_absence_identified=length(find((Bp(:)==0) & (Best(:)==0)))-dims;%%%���ǵ��Խ���Ԫ�ز���
% How many connections were incorrectly thought to be absent
% but which actually were present in the generating model?
% (Note that if very weak connections were pruned this is not
% very significant.)%%%��ȷ��֦������
truepruned = find((Bp(:)~=0) & (Best(:)==0));
maxtruepruned = max(abs(Bp(truepruned)));
FN = length(truepruned);%%%��ȷ��֦������

% if ntruepruned,
%     fprintf('Number of true connections pruned: %d [max was %.3f]\n', ...
% 	    ntruepruned, maxtruepruned );
% else
%     fprintf('Number of true connections pruned: 0\n');
% end
%     
% How many spurious connections were added? (i.e. connections
% absent in the generating model but which the algorithm thought
% were present.) Again, if very weak new connections were added
% this is not very bad, but of course if significant connections
% were spuriously included that is quite bad.%%%��������֦
superfluous = find((Bp(:)==0) & (Best(:)~=0));
maxsuperfluous = max(abs(Best(superfluous)));
FP = length(superfluous);%%%��������֦
kkk
kest
end