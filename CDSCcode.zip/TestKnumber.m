clc
clear
addpath(genpath('.\dataset'));
addpath(genpath('.\algo'));
addpath(genpath('.\LiNGAM'));
addpath(genpath('.\Dlingam-1.2(basic)'));
[skeleton,names] = readRnet( '.\dataset\diabetes.net');
skeleton=sortskeleton(skeleton);
L=Laplacian(skeleton);
[v,d]=eig(L);
 [Saver,PosSaver,NegSaver]=OurAlgo_Split_Main(L,8)