clc;clear;
format default
addpath(genpath('.\dataset'));
addpath(genpath('.\algo'));
addpath(genpath('.\LiNGAM'));
addpath(genpath('.\Dlingam-1.2(basic)'))
%% ����skeleton 
%[skeleton,names] = readRnet( '.\dataset\asia.net');
%[skeleton,names] = net2sketelon( '.\dataset\insurance.net');
  % [skeleton,names] = net2sketelon( '.\dataset\Alarm.net');
% [skeleton,names] = readRnet( '.\dataset\barley.net');
 %[skeleton,names] = net2sketelon( '.\dataset\hailfinder.net');
 %[skeleton,names] = net2sketelon( '.\dataset\win95pts.net');
[skeleton,names] = readRnet( '.\dataset\andes.net');
%[skeleton,names] = readRnet( '.\dataset\diabetes.net');
skeleton=sortskeleton(skeleton);
%% ��������
m = size(skeleton, 2);
sigma=0.1; 
k=2; %bestK
rt=2; %repeat times
FinalSkeleton=cell(rt,1);%���ս���Ǽܾ���
for q=1:rt %��FinalSkeleton�ķ���Ԥ�����ڴ�
    FinalSkeleton{q,1}=zeros(m);
end
%% Ԥ�����ڴ�
timeReCIT=zeros(rt,1);
timeSADA=zeros(rt,1);
timeCAPA=zeros(rt,1);
timeOA=zeros(rt,1);
ScoreReCIT=zeros(rt,7);
ScoreSADA=zeros(rt,7);
ScoreCAPA=zeros(rt,7);
ScoreOurAlgo=zeros(rt,7);
Compare_SADA=zeros(rt,5);
Compare_CAPA=zeros(rt,5);
Compare_RCIT=zeros(rt,5);
 %% ����  
%for j=1:5
    nSample=2*m;
    for s = 1:rt %ѭ������
        %data1 = SEMDataGenerator(skeleton, 500, 'uniform', 0.3);
        data=SEMDataGenerator(skeleton, nSample, 'uniform', 0.3);
    %% OurAlgo
            startOA=tic;%��ʼ��ʱ
            [W,~,S,L]=Laplacian(data,m,sigma);
            [Saver,~,~,~,~] = OurAlgoSplitMainNew4(L,k);%�Ƚ����׾������
            [fs,cut]=Final_Split_AutoNodes(Saver,W,k,m);%����cut
            [SplitData,SplitSkeleton]=Global_Split(fs,data,skeleton,k); %�õ����κ���������Ӧ�Ǽ�
            Result_CSkeleton=cell(k,1);
            for i=1:k 
                rc=zeros(m,m); %result Cskeleton
                [Cskeleton,~] = PC_PaCoTest(SplitData{i,1},SplitSkeleton{i,1},3);
                rc(fs{i,1},fs{i,1})=Cskeleton; 
                Result_CSkeleton{i,1}=rc;
           end
            for  j=1:k
                FinalSkeleton{s,1}=FinalSkeleton{s,1}+Result_CSkeleton{j,1};
            end       
            ScoreOurAlgo(s,:)=ScoreSkeleton(FinalSkeleton{s,1},skeleton);
            timeOA(s,:)=toc(startOA);
    %% SADA
        start2=tic;
        Recall_SADA=0;
        Precision_SADA=0;
        skeletonSADA=zeros(m);
        E = SADA_Main(data,(2*1.25+2)^2);
         for i=1:size(E,1)
                skeletonSADA(E(i,1),E(i,2))=1;
         end
       ScoreSADA(s,:)=ScoreSkeleton(skeletonSADA,skeleton);
        timeSADA(s,1)=toc(start2);
    %% CAPA
        start3=tic;
        [Ds_Temp,AM,BM,CM,DM] = find_Ds_Temp(data,2);
        [CAPA_skeleton,PTime1,PCTime1,OCM1] = CAPA(data,skeleton,3,2,Ds_Temp);
        skeletonByVs = VSdirection(CAPA_skeleton,AM,BM);
        skeletonByReCIT = ReCITdirection(CAPA_skeleton,AM,CM,DM); % by ReCIT
        Dskeleton = mergeSkeleton(skeletonByVs,skeletonByReCIT); % merge
        ScoreCAPA(s,:) = ScoreSkeleton(Dskeleton,skeleton);
        timeCAPA(s,1)=toc(start3);
    %% ReCIT
        start1=tic;
         [~,~,Cskeleton_RCIT,Dskeleton_RCIT] = PC_RCIT(data,skeleton,3);
        ScoreReCIT(s,:)=ScoreSkeleton(Cskeleton_RCIT,skeleton);
        timeReCIT(s,1)=toc(start1);
    %% PaCoTest
    % startP=tic;
    % [PaCoskeleton,~] = PC_PaCoTest(data,skeleton,3);
    % scorePaCo(s,:)=ScoreSkeleton(PaCoskeleton,skeleton);
    % timeP(s,1)=toc(startP);

    %% Compare
        [Compare_SADA(s,:)]=CMA(FinalSkeleton{s,1},skeletonSADA,skeleton);
        [Compare_CAPA(s,:)]=CMA(FinalSkeleton{s,1},Dskeleton,skeleton);
        [Compare_RCIT(s,:)]=CMA(FinalSkeleton{s,1},Cskeleton_RCIT,skeleton);
    end
    ScoreOurAlgoMean=mean(ScoreOurAlgo,1)
    ScoreOurAlgostd=std(ScoreOurAlgo,1)
    timeOAmean=mean(timeOA,1)
    
    % ScorePM=mean(scorePaCo,1)
    % ScorePstd=std(scorePaCo,1)
    % timaPM=mean(timeP,1)

    ScoreReCITmean=mean(ScoreReCIT,1)
    ScoreReCITstd=std(ScoreReCIT,1)
    timeReCITmean=mean(timeReCIT,1)

     ScoreSADAmean=mean(ScoreSADA,1)
     ScoreSADAstd=std(ScoreSADA,1)
    timeSADAmean=mean(timeSADA,1)

     ScoreCAPAmean=mean(ScoreCAPA,1)
     ScoreCAPAstd=std(ScoreCAPA,1)
     timeCAPAmean=mean(timeCAPA,1)

    Compare_SADA_mean=mean(Compare_SADA,1)
    Compare_CAPA_mean=mean(Compare_CAPA,1)
    Compare_RCIT_mean=mean(Compare_RCIT,1)
   


    

    
