clc;
addpath('D:\Dropbox\lib\matlab\mymatlabtoolbox');
addpath('D:\Dropbox\papers\LargeScaleCausality\code\code\kernel-ica1_2');
addpath(genpath('D:\Dropbox\lib\matlab\graphViz4Matlab'));


rand('seed',0);
nNode=10;
nSample=1000;
nFreeNode=5;
nIndgree=1.5
noiseType='uniform';
noiseRatio=0.05;

skeleton = GenRandSkeleton(nNode, nFreeNode, nIndgree);
graphViz4Matlab('-adjMat',skeleton')
data=SEMDataGenerator(skeleton,nSample, noiseType, noiseRatio);
[idxA,idxB,idxCut]=crc_Split_new(data)
