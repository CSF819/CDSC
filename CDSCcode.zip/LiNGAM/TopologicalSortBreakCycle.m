function [GR]=TopologicalSortBreakCycle(G, W)
[n,n]=size(G);
GR=G;
sourcenode=false(n,1);
while true
   tmp = sum(G);
   idxSource=intersect (find(tmp==0), find(sourcenode==false));
   if ~isempty(idxSource)% find a source node,remove all the edges directed from the source
       G(idxSource, :)=false;
       sourcenode(idxSource)=true;
   else% can't find a source node, repeatly remove edges with the smalleat weight, until find a source
       while true
           W=G.*W;
           tmp=min(W(W>0));
           [idx1, idx2]=find(W==tmp);
           G(idx1, idx2)=false;% remove an edge
           GR(idx1, idx2)=false;% remove an edge
           tmp = sum(G);
           if ~isempty(find(tmp==0,1))% find a source
               break;
           end
       end
   end
   if sum(sum(G))==0
       break;
   end
end