addpath D:\Dropbox\lib\matlab\Causal_Explorer\Matlab_R14
set_path;
network_filename={'D:\Dropbox\lib\matlab\Causal_Explorer\Data\alarm_h.net'};
dataset_filename={'D:\Dropbox\lib\matlab\Causal_Explorer\Data\alarm_h.mat'};
nodes=bn_tiling(network_filename, dataset_filename, 2000, 2);